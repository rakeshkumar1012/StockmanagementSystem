# Stock-Management-system
Hello everyone, This was a mini project that i designed in the second year of my college. It is a java application that keeps track of the stock. It is basically written in java and works in netbeans.

Software requirements:
Netbeans- latest version/ last 2 versions
jdk- latest/ last 2 releases
